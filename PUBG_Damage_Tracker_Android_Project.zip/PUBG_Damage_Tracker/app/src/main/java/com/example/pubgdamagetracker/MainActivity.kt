package com.example.pubgdamagetracker

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var totalDamage = 0
    private var hits = 0
    private val history = mutableListOf<String>()
    private lateinit var damageView: TextView
    private lateinit var hitsView: TextView
    private lateinit var historyView: TextView
    private lateinit var damageInput: EditText

    private val prefs by lazy { getSharedPreferences("tracker", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        totalDamage = prefs.getInt("damage", 0)
        hits = prefs.getInt("hits", 0)
        history.addAll(prefs.getString("history", "")!!.split("\n").filter { it.isNotBlank() })
        buildScreen()
        refresh()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(16, 22, 30))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "PUBG DAMAGE TRACKER"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 22)
        }
        content.addView(title)

        damageView = statText("0", 42f, Color.rgb(255, 82, 82))
        content.addView(damageView)
        content.addView(labelText("ОБЩИЙ УРОН ЗА МАТЧ"))

        hitsView = statText("0", 28f, Color.WHITE)
        hitsView.setPadding(0, 20, 0, 0)
        content.addView(hitsView)
        content.addView(labelText("ПОПАДАНИЯ"))

        damageInput = EditText(this).apply {
            hint = "Введи урон, например 35"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 17f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(37, 48, 62))
        }
        val inputParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        inputParams.setMargins(0, 28, 0, 12)
        content.addView(damageInput, inputParams)

        val addButton = actionButton("ДОБАВИТЬ УРОН")
        addButton.setOnClickListener { addDamage() }
        content.addView(addButton)

        val hitButton = actionButton("+1 ПОПАДАНИЕ")
        hitButton.setOnClickListener {
            hits += 1
            save()
            refresh()
        }
        content.addView(hitButton)

        val newMatchButton = actionButton("НОВЫЙ МАТЧ / СОХРАНИТЬ РЕЗУЛЬТАТ")
        newMatchButton.setOnClickListener { finishMatch() }
        content.addView(newMatchButton)

        val resetButton = actionButton("СБРОСИТЬ ТЕКУЩИЙ МАТЧ")
        resetButton.setOnClickListener {
            totalDamage = 0
            hits = 0
            save()
            refresh()
            Toast.makeText(this, "Текущий матч сброшен", Toast.LENGTH_SHORT).show()
        }
        content.addView(resetButton)

        val historyTitle = TextView(this).apply {
            text = "ИСТОРИЯ МАТЧЕЙ"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 28, 0, 8)
        }
        content.addView(historyTitle)
        historyView = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 16)
        }
        content.addView(historyView)

        val note = TextView(this).apply {
            text = "Важно: урон вводится вручную. Приложение не считывает данные PUBG Mobile и не взаимодействует с игрой."
            textSize = 12f
            setTextColor(Color.rgb(165, 178, 194))
            setPadding(0, 18, 0, 8)
        }
        content.addView(note)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun statText(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(0, 8, 0, 0)
    }

    private fun labelText(value: String) = TextView(this).apply {
        text = value
        textSize = 11f
        setTextColor(Color.rgb(165, 178, 194))
        gravity = Gravity.CENTER
    }

    private fun actionButton(caption: String) = Button(this).apply {
        text = caption
        textSize = 13f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(184, 48, 54))
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 6, 0, 6)
        layoutParams = p
    }

    private fun addDamage() {
        val amount = damageInput.text.toString().toIntOrNull()
        if (amount == null || amount <= 0) {
            Toast.makeText(this, "Введи число больше нуля", Toast.LENGTH_SHORT).show()
            return
        }
        totalDamage += amount
        hits += 1
        damageInput.text.clear()
        save()
        refresh()
    }

    private fun finishMatch() {
        if (totalDamage == 0 && hits == 0) {
            Toast.makeText(this, "В этом матче пока нет данных", Toast.LENGTH_SHORT).show()
            return
        }
        history.add(0, "Урон: $totalDamage | Попадания: $hits")
        while (history.size > 20) history.removeAt(history.lastIndex)
        totalDamage = 0
        hits = 0
        save()
        refresh()
        Toast.makeText(this, "Результат сохранён", Toast.LENGTH_SHORT).show()
    }

    private fun save() {
        prefs.edit()
            .putInt("damage", totalDamage)
            .putInt("hits", hits)
            .putString("history", history.joinToString("\n"))
            .apply()
    }

    private fun refresh() {
        damageView.text = totalDamage.toString()
        hitsView.text = hits.toString()
        historyView.text = if (history.isEmpty()) "Пока нет сохранённых матчей" else
            history.mapIndexed { index, item -> "${index + 1}. $item" }.joinToString("\n")
    }
}
